package com.aisnap.camera.pro

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.aisnap.camera.pro.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
    private lateinit var cameraExecutor: ExecutorService
    private var activeTab = "BACKGROUND"

    private val backgrounds = listOf("Studio", "Beach", "Office", "City Night", "Mountains", "Luxury", "Garden", "Golden Hour", "Paris", "Desert", "Snow", "Neon")
    private val outfits = listOf("Suit", "Zulu", "Hoodie", "Dress", "Streetwear", "Formal", "Denim", "Traditional", "Sport", "Summer", "Evening", "Classic")

    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else Toast.makeText(this, R.string.camera_permission_required, Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        cameraExecutor = Executors.newSingleThreadExecutor()
        binding.captureButton.setOnClickListener { takePhoto() }
        binding.switchCameraButton.setOnClickListener {
            cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        }
        binding.backgroundsTab.setOnClickListener { setTab("BACKGROUND") }
        binding.outfitsTab.setOnClickListener { setTab("OUTFIT") }
        binding.galleryButton.setOnClickListener { openGallery() }
        binding.enhanceButton.setOnClickListener {
            Toast.makeText(this, "Enhance is a UI placeholder in this camera starter; connect an image enhancement API to enable AI upscaling.", Toast.LENGTH_LONG).show()
        }
        setTab("BACKGROUND")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else requestPermission.launch(Manifest.permission.CAMERA)
    }

    private fun setTab(tab: String) {
        activeTab = tab
        val selected = 0xFFFE2C55.toInt()
        val idle = 0xFFA1A1AA.toInt()
        binding.backgroundsTab.setTextColor(if (tab == "BACKGROUND") selected else idle)
        binding.outfitsTab.setTextColor(if (tab == "OUTFIT") selected else idle)
        binding.presetsContainer.removeAllViews()
        val choices = if (tab == "BACKGROUND") backgrounds else outfits
        choices.forEach { choice ->
            val chip = TextView(this).apply {
                text = choice
                textSize = 12f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setBackgroundColor(0xFF27272A.toInt())
                val params = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                params.setMargins(dp(5), 0, dp(5), 0)
                layoutParams = params
                setOnClickListener {
                    binding.resultText.text = "$choice selected · AI editing requires the image-edit API to be configured"
                    Toast.makeText(this@MainActivity, "$choice selected. Photo effects need a connected AI editing service.", Toast.LENGTH_SHORT).show()
                }
            }
            binding.presetsContainer.addView(chip)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
                binding.statusText.text = "LIVE CAMERA"
            } catch (exc: Exception) {
                binding.statusText.text = "CAMERA UNAVAILABLE"
                Toast.makeText(this, "Could not start camera: ${exc.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run {
            Toast.makeText(this, "Camera is not ready yet", Toast.LENGTH_SHORT).show(); return
        }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AISNAP_$timestamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Snap")
        }
        val options = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                runOnUiThread {
                    binding.resultText.text = "Photo saved to Pictures/AI Snap"
                    Toast.makeText(this@MainActivity, "Photo captured!", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Capture failed: ${exception.localizedMessage}", Toast.LENGTH_LONG).show() }
            }
        })
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show() }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
    }
}
